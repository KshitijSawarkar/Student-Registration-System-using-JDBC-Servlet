package attendancelogin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Scanner;
import java.sql.*;
 
public class register extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet register</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet register at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        
        //here we need to add jdbc connection and take values from jsp and insert it into db
        
        String fullname = request.getParameter("fname");
        String username = request.getParameter("uname");
        String email = request.getParameter("email");
        String password = request.getParameter("pwd");
        String confirmpass = request.getParameter("cpwd");
        String attend = request.getParameter("attendance");
        
        //here we r taking user enter values from jsp and with the help of this servlet we r able to insert it into db
        
        try{
            Connection con;
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/register","Saie","Sanku@03");
            out.println("Connected");
            
            //now we r connected to the db
            String sql="insert into register(fullname,username,email,password,confirmpass,attendance) values(?,?,?,?,?,?)";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1,fullname);
            ps.setString(2,username);
            ps.setString(3,email);
            ps.setString(4,password);
            ps.setString(5,confirmpass);
            ps.setString(6,attend);
            
            int ra = ps.executeUpdate();
            out.println(ra+" rows inserted");
            
            out.print("You have been registered successfully");
        
        }
        catch(Exception e){
          System.out.println("ERROR::"+e.getMessage());
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}