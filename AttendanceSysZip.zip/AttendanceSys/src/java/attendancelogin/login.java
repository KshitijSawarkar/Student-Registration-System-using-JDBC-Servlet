package attendancelogin;

import java.io.IOException;
import java.sql.*;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "login", urlPatterns = {"/login"})
public class login extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) 
        {
          String _username=request.getParameter("username");
          
          String _password=request.getParameter("pwd");
          
          
          Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/register","Saie","Sanku@03");
          System.out.println("Connection successful"); 
          
          Statement stmt = con.createStatement();
          String query = "select * from register where username='"+_username+"'";
          
          String un =null;
          String pw=null;
          int att=0;
          ResultSet rs= stmt.executeQuery(query);
          while(rs.next()){
              un=rs.getString("username") ;
              pw = rs.getString("password");
              att = rs.getInt("attendance");
          }
          stmt.close();
          con.close();
          
          if(_username != null && _password !=null){
              if(_username.equals(un)&& _password.equals(pw)){
               out.print("Welcome! Your attendance is "+att);
                  
              }else{
                  out.println("Invalid input");
              }}
          else{
                   out.println("empty username or password");
              }
          }
         catch(SQLException se){
            se.printStackTrace();
        }
        
        }
    

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}


